create definer = root@localhost view vw_all_account_movements as
select `acc`.`account_id`         AS `account_id`,
       `acc`.`account_name`       AS `account_name`,
       `m`.`movement_id`          AS `movement_id`,
       `m`.`date_id`              AS `date_id`,
       `m`.`movement_desc`        AS `movement_desc`,
       `m`.`amount`               AS `amount`,
       `acc`.`account_balance`    AS `account_balance`,
       `cat`.`account_code`       AS `account_code`,
       `cat`.`account_code_desc`  AS `account_code_desc`,
       `cmt`.`movement_code`      AS `movement_code`,
       `cmt`.`movement_code_desc` AS `movement_code_desc`
from ((((`finance_control`.`account` `acc` join `finance_control`.`movement_account` `ma` on ((`acc`.`account_id` = `ma`.`account_id`))) join `finance_control`.`movement` `m` on ((`ma`.`movement_id` = `m`.`movement_id`))) join `finance_control`.`cat_account_type` `cat` on ((`acc`.`account_type` = `cat`.`account_code`)))
       join `finance_control`.`cat_movement_type` `cmt` on ((`m`.`movement_type` = `cmt`.`movement_code`)))
order by `acc`.`account_id`, `m`.`date_id` desc;

