create
  definer = root@localhost procedure new_account_movement(IN pi_account_id bigint, IN ps_movement_type varchar(8),
                                                          IN pf_amount double, IN ps_description varchar(512),
                                                          IN pd_date datetime)
begin

  declare li_movement_id bigint;

  insert into movement value (default, ps_description,
                          case when (ps_movement_type in ('O', 'RO')) then -1 * pf_amount else pf_amount end, ps_movement_type, default);

  update account
  set account_balance = case when (ps_movement_type in ('O', 'RO')) then account_balance - pf_amount else account_balance + pf_amount end
  where account_id = pi_account_id;

  set li_movement_id = (select max(movement_id) from movement);

  insert into movement_account value (li_movement_id, pi_account_id);

end;

