create definer = root@localhost view app_vw_all_account_info as
select `m1`.`account_id`         AS `account_id`,
       `m1`.`account_name`       AS `account_name`,
       `m1`.`account_balance`    AS `account_balance`,
       `m1`.`account_type`       AS `account_type`,
       count(`m2`.`movement_id`) AS `no_movements`
from (`finance_control`.`account` `m1`
       left join `finance_control`.`movement_account` `m2` on ((`m1`.`account_id` = `m2`.`account_id`)))
group by `m1`.`account_id`
order by `m1`.`account_id`;

