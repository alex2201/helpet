create
  definer = root@localhost procedure calculate_balance(IN pi_account_id bigint)
begin

  update account
  set account_balance = (select sum(amount)
                 from movement mov
                        inner join movement_account ma on mov.movement_id = ma.movement_id and pi_account_id = ma.account_id)
  where account_id = pi_account_id;

end;

